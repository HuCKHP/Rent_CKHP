package com.groupone.vo;

public class GoodlistVO {
	private String id; 
	private int bno;
	private int heartval;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getHeartval() {
		return heartval;
	}
	public void setHeartval(int heartval) {
		this.heartval = heartval;
	}
	
	
	
	
}
