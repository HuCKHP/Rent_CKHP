package com.groupone.vo;

public class RentcarVO {
   
   int cno;
   String cartype;
   String carname;
   String cindate;
   int pay;
   String grade;
   String cfile;
   public int getCno() {
      return cno;
   }
   public void setCno(int cno) {
      this.cno = cno;
   }
   public String getCartype() {
      return cartype;
   }
   public void setCartype(String cartype) {
      this.cartype = cartype;
   }
   public String getCarname() {
      return carname;
   }
   public void setCarname(String carname) {
      this.carname = carname;
   }
   public String getCindate() {
      return cindate;
   }
   public void setCindate(String cindate) {
      this.cindate = cindate;
   }
   public int getPay() {
      return pay;
   }
   public void setPay(int pay) {
      this.pay = pay;
   }
   public String getGrade() {
      return grade;
   }
   public void setGrade(String grade) {
      this.grade = grade;
   }
   public String getCfile() {
      return cfile;
   }
   public void setCfile(String cfile) {
      this.cfile = cfile;
   }
      
}